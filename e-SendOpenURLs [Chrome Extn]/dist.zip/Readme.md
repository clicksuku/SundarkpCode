## About this tool ##

This Chrome extension provides two functionalities

   * Provide a menu select tabs on open Chrome browser and send it to GMail.
   * Open the sent URLs on the Chrome Browser


## Languages ##

Chrome Extension, JQuery
     
## Steps to Install ##

### Pre-Requisites ###

Chrome Browser

### Installation ###
  
[Install from Chrome WebStore](https://chrome.google.com/webstore/detail/send-open-urls/ohapipgmanomnljkmlkainclgblifagk)

## Demo ##

<a href="http://www.youtube.com/watch?feature=player_embedded&v=i3Cxm4Xi6TM" target="_blank">
<img src="http://img.youtube.com/vi/i3Cxm4Xi6TM/0.jpg" alt="https://www.youtube.com/watch?v=i3Cxm4Xi6TM" width="240" height="180" border="10" /></a>

# License #
New APACHE License - Copyright(c) 2014, Sundara Kumar Padmanabhan. 
See [License](http://www.apache.org/licenses/LICENSE-2.0.html) for details.
